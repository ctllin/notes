#ifndef _WINFIX__H_
#define _WINFIX__H_

#ifdef __cplusplus
extern "C" {
#endif

#include "win32fixes.h"

#ifdef __cplusplus
}
#endif

#endif