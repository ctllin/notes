# RedisStudio (Redis GUI Client)

## Download
[![GitHub release](https://img.shields.io/github/release/cinience/RedisStudio.svg?style=flat-square)](https://github.com/cinience/RedisStudio/releases) 
  
## Introduction
    1. Redis Studio is Redis GUI Client，support Windows xp, windows 7, windows 8
    2. Kernel is MSOpen hiredis, GUILIB is duilib
    3. Support official Redis 2.6 2.7 2.8 new..

![UI](https://raw.githubusercontent.com/cinience/RedisStudio/master/docs/redis.png "RedisStudio UI")

## Supported platforms

    * Windows xp
    * Windows Vista
    * Windows 7
    * Windows 8, 8.1
    * Windows 10
  
## Supported Redis version
    * Official Redis 2.6
    * Official Redis 2.7
    * Official Redis 2.8
    * Official Redis new



