﻿#include "StdAfx.h"
#include "Runnable.h"


namespace Base {


Runnable::Runnable()
{
}


Runnable::~Runnable()
{
}


} // namespace Base
